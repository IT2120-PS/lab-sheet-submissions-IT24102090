# Lab Sheet 09 - Exercise: Baking Time
# Set working directory 
setwd("C:\\Users\\adith\\Desktop\\IT24102090")

# Set seed for reproducibility
set.seed(123)

# Part i: Generate 25 random numbers from N(45, 2)
mu_bake <- 45
sigma_bake <- 2
n_bake <- 25
sample_bake <- rnorm(n_bake, mean = mu_bake, sd = sigma_bake)
print(round(sample_bake, 3))  # Display sample

# Calculate sample mean
mean_bake <- mean(sample_bake)
cat("Sample Mean:", round(mean_bake, 3), "\n")

# Part ii: One-sample z-test approximation (use t.test with known sigma for SE)
t_test_bake <- t.test(sample_bake, mu = 46, alternative = "less", conf.level = 0.95)
print(t_test_bake)

# Extract test statistic and p-value
cat("Test Statistic (z approx t):", round(t_test_bake$statistic, 3), "\n")
cat("p-value:", round(t_test_bake$p.value, 3), "\n")

# Manual z-stat (using known sigma)
se_bake <- sigma_bake / sqrt(n_bake)
z_stat_bake <- (mean_bake - 46) / se_bake
p_z_bake <- pnorm(z_stat_bake)
cat("Exact z-statistic:", round(z_stat_bake, 3), "\n")
cat("Exact p-value:", round(p_z_bake, 3), "\n")

# Decision
if (t_test_bake$p.value < 0.05) {
  cat("Decision: Reject H0 (mean < 46 min)\n")
} else {
  cat("Decision: Fail to reject H0\n")
}