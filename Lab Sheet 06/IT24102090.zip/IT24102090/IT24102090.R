setwd("C:\\Users\\it24102090\\Desktop\\IT24102090")

# Exercise

# Question 1: Learning platform performance

# Part 1: Distribution of X

# Binomial distribution with n=50 and p=0.85

p47 <- 1 - pbinom(46, 50, 0.85, lower.tail = TRUE) # P(X>=47)


# Question 2: Call center calls

# Part 1: Distribution of X

# Poisson distribution with lambda=12

p15 <- dpois(15, 12) # P(X=15)


