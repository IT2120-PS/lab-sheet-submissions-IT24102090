# Lab Sheet 08 - Exercise: Laptop Weights
# Set working directory 
setwd("C:\\Users\\adith\\Desktop\\IT24102090")

# Read the data file
laptop_data <- read.table("Exercise - LaptopsWeights (1).txt", header = TRUE)
colnames(laptop_data) <- "Weight"  # Standardize column name
attach(laptop_data)  # Attach here to make 'Weight' accessible

# Question 1: Calculate population mean and population standard deviation
pop_mean_laptop <- mean(Weight)
pop_var_laptop <- mean((Weight - mean(Weight))^2)  # Population variance (divide by N)
pop_sd_laptop <- sqrt(pop_var_laptop)
cat("Population Mean:", pop_mean_laptop, "\n")
cat("Population Standard Deviation:", pop_sd_laptop, "\n")

# Question 2: Generate 25 random samples of size 6 with replacement
n_samples_laptop <- 25
sample_size_laptop <- 6
sample_weights <- matrix(NA, nrow = n_samples_laptop, ncol = sample_size_laptop)

# Loop to generate samples with replacement
for(i in 1:n_samples_laptop) {
  sample_weights[i, ] <- sample(Weight, sample_size_laptop, replace = TRUE)
}

# Calculate sample means and sample standard deviations (sd() uses n-1)
sample_means_laptop <- apply(sample_weights, 1, mean)
sample_sds_laptop <- apply(sample_weights, 1, sd)

# Display in table format (copy this output to your Word doc)
laptop_sample_table <- data.frame(Sample = 1:n_samples_laptop, 
                                  Mean = round(sample_means_laptop, 4), 
                                  Std_Dev = round(sample_sds_laptop, 4))
print(laptop_sample_table)

# Question 3: Calculate mean and SD of the sample means
mean_of_sample_means_laptop <- mean(sample_means_laptop)
sd_of_sample_means_laptop <- sd(sample_means_laptop)

cat("Mean of Sample Means:", round(mean_of_sample_means_laptop, 4), "\n")
cat("Standard Deviation of Sample Means:", round(sd_of_sample_means_laptop, 4), "\n")

# Relationships
expected_sd_sample_means <- pop_sd_laptop / sqrt(sample_size_laptop)
cat("True Population Mean:", round(pop_mean_laptop, 4), "vs. Mean of Sample Means:", round(mean_of_sample_means_laptop, 4), "\n")
cat("Relationship: The sample mean is an unbiased estimator of the population mean (values are approximately equal).\n")
cat("Expected SD of Sample Means (Standard Error):", round(expected_sd_sample_means, 4), "\n")
cat("Actual SD of Sample Means:", round(sd_of_sample_means_laptop, 4), "\n")
cat("Relationship: The SD of sample means approximates the population SD / √n due to the sampling distribution of the mean.\n")

# Detach data
detach(laptop_data)