setwd("C:\\Users\\it24102090\\Desktop\\IT24102090")

observed<-c (55,62,43,46,50)
prob<- c (.2, .2, .2, .2, .2)

chisq.test(x=observed, p=prob)

file_path<-" http://www.sthda.com/sthda/RDoc/data/housetasks.txt "

housetasks <- read.csv("Data.csv", row.names=1)

housetasks

chisq <- chisq.test(housetasks)
chisq

#Exercise

observed_snacks <- c(120, 95, 85, 100)

chisq.test(observed_snacks, p=rep(1/4, 4))


