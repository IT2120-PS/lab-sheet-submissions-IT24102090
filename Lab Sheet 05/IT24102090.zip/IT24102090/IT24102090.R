setwd("C:\\Users\\adith\\Desktop\\IT24102090")
getwd()

Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

# Define breaks for nine class intervals
breaks_delivery <- seq(20, 70, length.out = 10)

# Draw histogram with right open intervals
hist(Delivery_Times$Delivery_Time_.minutes., breaks = breaks_delivery, right = FALSE,
     main = "Histogram of Delivery Times", xlab = "Delivery Time (minutes)", ylab = "Frequency")

# Calculate frequencies
freq_delivery <- table(cut(Delivery_Times$Delivery_Time_.minutes., breaks = breaks_delivery, right = FALSE))

# Calculate cumulative frequencies
cum_freq_delivery <- cumsum(freq_delivery)

# Draw cumulative frequency polygon
plot(breaks_delivery, c(0, cum_freq_delivery), type = "l",
     main = "Cumulative Frequency Polygon (Ogive) for Delivery Times",
     xlab = "Delivery Time (minutes)", ylab = "Cumulative Frequency")
points(breaks_delivery, c(0, cum_freq_delivery), pch = 19)
